class Animal:
    def __init__(self, nome, idade, peso, tamanho, alergia, doenca):
        self.nome = nome
        self.idade = idade
        self.peso = peso
        self.tamanho = tamanho
        self.alergia = alergia
        self.doenca = doenca

    def exibirInfo(self):
        print(f'Nome: {self.nome}')
        print(f'Idade: {self.idade}')
        print(f'Peso: {self.peso}')
        print(f'Tamanho: {self.tamanho}')
        print(f'Alergia: {self.alergia}')
        print(f'Doença: {self.doenca}')


class CaninosouFelinos(Animal):
    def __init__(self, nome, idade, peso, tamanho, alergia, doenca, raca, idCaninosouFelinos):
        super().__init__(nome, idade, peso, tamanho, alergia, doenca)
        self.raca = raca
        self.idCaninosouFelinos = idCaninosouFelinos

    def exibirInfo(self):
        super().exibirInfo()
        print(f"Raça do animal: {self.raca}\n"
              f"ID de Caninos e Felinos: {self.idCaninosouFelinos}")


class Roedores(Animal):
    def __init__(self, nome, idade, peso, tamanho, alergia, doenca, raca, idRoedor):
        super().__init__(nome, idade, peso, tamanho, alergia, doenca)
        self.raca = raca
        self.idRoedor = idRoedor

    def exibirInfo(self):
        super().exibirInfo()
        print(f"Raça do animal: {self.raca}\n"
              f"ID de Roedores: {self.idRoedor}")


class Ave(Animal):
    def __init__(self, nome, idade, peso, tamanho, alergia, doenca, especie, idAve):
        super().__init__(nome, idade, peso, tamanho, alergia, doenca)
        self.especie = especie
        self.idAve = idAve

    def exibirInfo(self):
        super().exibirInfo()
        print(f"Especie do animal: {self.especie}\n"
              f"ID das Aves: {self.idAve}")
