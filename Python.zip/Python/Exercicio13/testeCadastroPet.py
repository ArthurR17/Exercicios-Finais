from cadastroPet import Animal, CaninosouFelinos, Roedores, Ave

print("{0:-^90}".format(""))
print("{0:-^90}".format(" RH360 -  CADASTRO DO PET - PETPALLET" ))
print("{0:-^90}".format(""))

listarCaninosouFelinos = []
listarRoedores = []
listarAves = []


def menu():
    print("1-Cadastro\n"
          "2-Listar todos os cadastros\n"
          "3-Pesquisar Caninos ou felinos\n"
          "4-Pesquisar Roedores\n"
          "5-Pesquisar Aves\n"
          "6-Sair")
    return int(input("Escolha uma das opções acima:"))


while True:
    escolha = menu()
    if escolha == 1:
        nome = str(input("Digite o nome do seu Pet: "))
        idade = int(input("Digite a idade do seu Pet: "))
        peso = input("Digite o peso do seu Pet: ")
        tamanho = input("Digite o tamanho do seu Pet: ")
        alergia = str(input("Digite se seu Pet tem algum tipo de alergia: "))
        doenca = str(input("Digite se seu Pet tem alguma doença: "))
        tipoAnimal = int(input("Qual tipo é seu animal?\n"
                               "Digite '1' para Canídeos ou Felinos, '2' para Roedores, '3' para Aves e '4' para Sair: "))
        if tipoAnimal == 1:
            print("{0:-^190}".format(""))
            print("{0:-^190}".format("RH360- CADASTRO DE CANÍDEOS OU FELINOS - PETPALLET"))
            print("{0:-^190}".format(""))
            raca = str(input("Digite a raça do seu animal: "))
            idCaninosouFelinos = int(input("Digite um ID para os seu animal:"))
            caninosouFelinos = CaninosouFelinos(nome, idade, peso, tamanho, alergia, doenca, raca, idCaninosouFelinos)
            listarCaninosouFelinos.append(caninosouFelinos)
            caninosouFelinos.exibirInfo()

        elif tipoAnimal == 2:
            print("{0:-^90}".format(""))
            print("{0:-^90}".format(" RH360 - CADASTRO DE ROEDORES - PETPALLET"))
            print("{0:-^90}".format(""))
            raca = str(input("Digite a raça do seu Roedor: "))
            idRoedor = int(input("Digite um ID para o seu animal: "))
            roedores = Roedores(nome, idade, peso, tamanho, alergia, doenca, raca, idRoedor)
            listarRoedores.append(roedores)
            roedores.exibirInfo()

        elif tipoAnimal == 3:
            print("{0:-^90}".format(""))
            print("{0:-^90}".format(" RH360 - CADASTRO DE AVES - PETPALLET"))
            print("{0:-^90}".format(""))
            especie = str(input("Digite a espécie da sua Ave: "))
            idAves = int(input("Digite um ID para o seu animal: "))
            aves = Ave(nome, idade, peso, tamanho, alergia, doenca, especie, idAves)
            listarAves.append(aves)
            aves.exibirInfo()
        elif tipoAnimal == 4:
            print("Saindo.")
            break
        else:
            print("Opção inválida!")
    elif escolha == 2:
        for caninosouFelinos in listarCaninosouFelinos:
            caninosouFelinos.exibirInfo()
        for roedores in listarRoedores:
            roedores.exibirInfo()
        for aves in listarAves:
            aves.exibirInfo()

    elif escolha == 3:
        idCaninosouFelinos = input("Digite o ID do seu animal que deseja pesquisar: ")
        for caninosouFelinos in listarCaninosouFelinos:
            if caninosouFelinos.idCaninosouFelinos == idCaninosouFelinos:
                caninosouFelinos.exibirInfo()
                break

    elif escolha == 4:
        idRoedor = int(input("Digite o ID do seu animal que deseja pesquisar: "))
        for roedores in listarRoedores:
            if roedores.idRoedor == idRoedor:
                roedores.exibirInfo()
                break

    elif escolha == 5:
        idAves = int(input("Digite o ID do seu animal que deseja pesquisar: "))
        for aves in listarAves:
            if aves.idAve == idAves:
                aves.exibirInfo()
                break

    elif escolha == 6:
        break
    
    else:
        print("Opção inválida, tente outra vez.")
