medicamentos = {
    'Dipiriona': False,
    'Paracetamol': False,
    'Alivium': False,
    'Doril': True,
    'Dorflex': True,
    'Novalgina': True,
}


def verificar_prescricao():
    print("Medicamentos: \n")
    for item in medicamentos:
        print(item)
    while True:
        nome = input("Digite o nome do medicamento: ")
        if nome in medicamentos:
            if medicamentos[nome]:
                print(f"O medicamento {nome} precisa de prescrição!")
                return True
            elif not medicamentos[nome]:
                print(f"O medicamento {nome} não precisa de prescrição!")
                return False
            else:
                print("Medicamento não encontrado!")


verificar_prescricao()
