
def calcular_desconto(valor_total):
    desconto = 0.15
    valor_total = valor_total - (valor_total * desconto)
    print(f"Desconto: {desconto * 100}%")
    print(f"O valor total com desconto é de R${valor_total:0.2f}")
    return valor_total


cupom = input("Parabéns, você ganhou um desconto de 15%! Digite o cupom LEGAL15 para aplicar o desconto: ")
if cupom == "LEGAL15":
    valor_total = float(input("Digite o valor total da compra: "))
    calcular_desconto(valor_total)
else:
    print("Cupom inválido!")