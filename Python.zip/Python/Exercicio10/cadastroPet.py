import json

print("-" * 87)
print("-" * 20 + " RH 360 - CADASTRO DE PETS - PETPALLET " + "-" * 20)
print("-" * 87)


class Pet:
    # Definir os atributos da classe
    def __init__(self, nome, idade, raca, sexo, peso):
        self.nome = nome
        self.idade = idade
        self.raca = raca
        self.sexo = sexo
        self.peso = peso

    def cadastrarPet(self, nome, idade, raca, sexo, peso):
        # Carregar o arquivo do pet
        with open("cadastroPet.json", "r", encoding="utf-8") as arquivo_json:
            dados = json.load(arquivo_json)

        # Adicionar novo pet
        novo_registro = {
            "Nome": nome,
            "Idade": idade,
            "Raca": raca,
            "Sexo": sexo,
            "Peso": peso
        }

        dados.append(novo_registro)

        # Atualizar o arquivo do pet
        with open("cadastroPet.json", "w", encoding="utf-8") as arquivo_json:
            json.dump(dados, arquivo_json, indent=4)
        print("Novo Pet adicionado com sucesso!")

    def listarPets(self):
        # Carregar o arquivo do pet
        with open("cadastroPet.json", "r", encoding="utf-8") as arquivo_json:
            dados = json.load(arquivo_json)

        # Listar os pets
        for item in dados:
            print(f"Nome: {item['Nome']}")
            print(f"Idade: {item['Idade']}")
            print(f"Raça: {item['Raca']}")
            print(f"Sexo: {item['Sexo']}")
            print(f"Peso: {item['Peso']}")
            print("-" * 10)

    def excluirPet(self, nome):
        # Carregar o arquivo do pet
        with open("cadastroPet.json", "r", encoding="utf-8") as arquivo:
            dados = json.load(arquivo)

        indice_a_excluir = None
        # Encontrar o índice do pet a ser excluído
        for i, item in enumerate(dados):
            if item.get("Nome") == nome:
                indice_a_excluir = i
                break
        # Se o pet for encontrado, ele é excluído
        if indice_a_excluir is not None:
            registro_excluido = dados.pop(indice_a_excluir)

            # Atualizar o arquivo do pet
            with open("cadastroPet.json", "w", encoding="utf-8") as arquivo:
                json.dump(dados, arquivo, indent=4)

            # Mostrar os dados do pet excluído
            if registro_excluido is not None:
                print(f"Pet {pet_exclusao} excluído com sucesso!")
                print(f"Idade: {registro_excluido['Idade']}")
                print(f"Raça: {registro_excluido['Raca']}")
                print(f"Sexo: {registro_excluido['Sexo']}")
                print(f"Peso: {registro_excluido['Peso']}")
        else:
            print(f"Funcionário {nome} não foi encontrado.")


# Instanciar a classe Pet
pet = Pet("nome", "idade", "raca", "sexo", "peso")

while True:
    print("\nEscolha uma das opções abaixo:\n")
    print("1 - Cadastrar Pet")
    print("2 - Listar Pets")
    print("3 - Excluir Pet")
    print("4 - Voltar ao menu principal")

    opcao = input("\nDigite o número da opção desejada: ")

    if opcao == "1":
        # Solicitar os dados do pet
        pet.nome = input("Digite o nome do pet: ")
        pet.idade = input("Digite a idade do pet: ")
        pet.raca = input("Digite a raça do pet: ")
        pet.sexo = input("Digite o sexo do pet: ")
        pet.peso = input("Digite o peso do pet: ")
        # Chamar a função para cadastrar o pet
        pet.cadastrarPet(pet.nome, pet.idade, pet.raca, pet.sexo, pet.peso)
    elif opcao == "2":
        # Chamar a função para listar os pets
        pet.listarPets()
    elif opcao == "3":
        # Solicitar o nome do pet a ser excluído
        pet_exclusao = input("Digite o nome do pet a ser excluído: ")

        # Chamar a função para excluir o pet
        registro_excluido = pet.excluirPet(pet_exclusao)
    elif opcao == "4":
        exec(open("escolhaUsuario.py", encoding="utf-8").read())
  