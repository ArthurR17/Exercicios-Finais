print("-" * 70)
print("-" * 25 + " RH 360 - SÃO SABRINO " + "-" * 24)
print("-" * 70)


print("\nSeja bem-vindo ao RH da SÃO SABRINO!\n")
nome = input("Digite o nome de usuário: ")
input("Digite a senha: ")

print(f"\nSeja bem-vindo(a), {nome}!")

print("\nEscolha uma das opções abaixo:\n")
print("1 - Acessar cadastro de animais")
print("2 - Agendamento de banho/tosa/vacina")

opcao = input("\nDigite o número da opção desejada: ")

if opcao == '1':
    exec(open('cadastroPet.py', encoding='utf-8').read())
elif opcao == '2':
    exec(open('agendamento.py', encoding='utf-8').read())
else:
    print("Opção inválida. Por favor, escolha uma opção válida.")
