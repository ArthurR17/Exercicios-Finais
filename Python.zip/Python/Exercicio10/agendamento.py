import json


class Agendamento:

    def agendar(self, nome_pet, data, horario, servico):

        # Carregar o arquivo de agendamento
        with open("../../Aula 16 - Trabalho Final/agendamento.json", "r", encoding="utf-8") as arquivo_json:
            dados = json.load(arquivo_json)

        novo_registro = {
            "Nome do pet": nome_pet,
            "Data": data,
            "Horario": horario,
            "Servico": servico
        }

        dados.append(novo_registro)

        # Atualizar o arquivo de agendamento
        with open("../../Aula 16 - Trabalho Final/agendamento.json", "w", encoding="utf-8") as arquivo_json:
            json.dump(dados, arquivo_json, indent=4)
        print("Novo agendamento adicionado com sucesso!")

    def listarAgendamentos(self):
        # Carregar o arquivo de agendamento
        with open("../../Aula 16 - Trabalho Final/agendamento.json", "r", encoding="utf-8") as arquivo_json:
            dados = json.load(arquivo_json)
        # Listar os agendamentos

        for item in dados:
            print(f"Nome do pet: {item['Nome do pet']}")
            print(f"Data: {item['Data']}")
            print(f"Horário: {item['Horario']}")
            print(f"Serviço: {item['Servico']}")
            print("-" * 10)

    def listarHorarios(self):
        # Carregar o arquivo de horários
        with open("../../Aula 16 - Trabalho Final/horarios.json", "r", encoding="utf-8") as arquivo_json:
            dados = json.load(arquivo_json)

        # Listar os horários
        for item in dados:
            print(f"Segunda-feira: {item['Segunda-feira']}")
            print(f"Terça-feira: {item['Terça-feira']}")
            print(f"Quarta-feira: {item['Quarta-feira']}")
            print(f"Quinta-feira: {item['Quinta-feira']}")
            print(f"Sexta-feira: {item['Sexta-feira']}")
            print(f"Sábado: {item['Sábado']}")
            print(f"Domingo: {item['Domingo']}")
            print("-" * 10)


# Instanciar a classe Agendamento
agendar = Agendamento()

while True:
    print("\nEscolha uma das opções abaixo:\n")
    print("1 - Agendar banho, tosa e/ou vacina")
    print("2 - Listar agendamentos")
    print("3 - Ver horário de atendimento")
    print("4 - Voltar ao menu principal")

    opcao = input("\nDigite o número da opção desejada: ")
    if opcao == '1':
        nome_pet = input("Digite o nome do pet: ")
        data = input("Digite a data do agendamento: ")
        horario = input("Digite o horário do agendamento: ")
        servico = input("Digite o serviço a ser realizado (Banho/Tosa/Vacina): ")
        agendar.agendar(nome_pet, data, horario, servico)
    elif opcao == '2':
        agendar.listarAgendamentos()
    elif opcao == '3':
        agendar.listarHorarios()
    elif opcao == '4':
        exec(open('escolhaUsuario.py', encoding='utf-8').read())
