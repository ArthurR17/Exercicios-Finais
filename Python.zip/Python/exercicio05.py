socios = []


def verificar_socios(nome_socio):
    if nome_socio in socios:
        print("\nSócio encontrado!")
        print(f"Sócios:")
        for item in socios:
            print(f"{item}")
        return True
    else:
        print("Sócio não encontrado!")
        return False


print("Bem-vindo ao cadastro de sócios do clube!")
while True:
    print("Opções: ")
    print("1 - Cadastrar sócio")
    print("2 - Verificar sócio")
    print("3 - Sair")
    opcao = int(input("Digite a opção desejada: "))
    if opcao == 1:
        nome_socio = input("Digite o nome do sócio: ")
        print("Sócio cadastrado com sucesso!\n")
        socios.append(nome_socio)
    elif opcao == 2:
        nome_socio = input("Digite o nome do sócio: ")
        verificar_socios(nome_socio)
