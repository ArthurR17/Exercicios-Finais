import json

# Classe BelezaPura
class BelezaPura:
    def __init(self, nome, endereco):
        self.nome = nome
        self.endereco = endereco

# Classe ClinicaEstetica
class ClinicaEstetica:
    def __init__(self, nome, endereco, valor, tratamentos):
        self.nome = nome
        self.endereco = endereco
        self.valor = valor
        # Lista de tratamentos com seus respectivos valores
        self.tratamentos = {
            "Limpeza de pele": 50.00,
            "Esfoliação facial": 100.00,
            "Drenagem linfática": 200.00,
            "Massagem relaxante": 50.00,
            "Massagem terapêutica": 75.00,
        }

    # Método para mostrar tratamentos disponíveis ao cliente
    def tratamento_cliente(self):
        for tratamento, valor in self.tratamentos.items():
            print(f"\n{tratamento} - R${valor:0.2f}")

    # Método para agendar consulta e salvar no arquivo JSON
    def agendar_consulta(self):
        with open("exercicio07Clinica.json", "r") as file:
            dados = json.load(file)

        nome = input("Digite seu nome: ")
        horario = input("Digite o horário da consulta: ")
        tratamento = input("Digite o tratamento desejado: ")

        novo_registro = {
            "Nome": nome,
            "Horario": horario,
            "Tratamento": tratamento,
        }

        dados.append(novo_registro)

        with open("exercicio07Clinica.json", "w") as arquivo_json:
            json.dump(dados, arquivo_json, indent=4)

        print("Nova consulta registrada com sucesso!")

        # Verifica se o tratamento escolhido existe e mostra o valor
        if tratamento in self.tratamentos:
            print(f"O valor total é de R${self.tratamentos[tratamento]:0.2f}")
        else:
            print("Tratamento inválido.")

    # Método para gerenciar histórico e mostrar consultas registradas
    def gerenciar_historico(self):
        with open("exercicio07Clinica.json", "r") as arquivo_json:
            dados = json.load(arquivo_json)

        for item in dados:
            print(f"Nome: {item['Nome']}")
            print(f"Horário: {item['Horario']}")
            print(f"Tratamento: {item['Tratamento']}")
            print()

# Classe Procedimentos
class Procedimentos:
    def __init__(self, nome, endereco, valor, tratamentos):
        self.nome = nome
        self.endereco = endereco
        self.valor = valor
        # Lista de procedimentos com seus respectivos valores
        self.tratamentos = {
            "Progressiva": 50.00,
            "Cauterização": 100.00,
            "Reconstrução": 200.00,
            "Hidratação profunda": 50.00,
        }

    # Método para mostrar procedimentos disponíveis ao cliente
    def tratamento_cliente(self):
        for tratamento, valor in self.tratamentos.items():
            print(f"\n{tratamento} - R${valor:0.2f}")

    # Método para agendar consulta e salvar no arquivo JSON
    def agendar_consulta(self):
        with open("exercicio07Procedimentos.json", "r") as file:
            dados = json.load(file)

        nome = input("Digite seu nome: ")
        horario = input("Digite o horário da consulta: ")
        procedimento = input("Digite o procedimento desejado: ")

        novo_registro = {
            "Nome": nome,
            "Horario": horario,
            "Procedimento": procedimento,
        }

        dados.append(novo_registro)

        with open("exercicio07Procedimentos.json", "w") as arquivo_json:
            json.dump(dados, arquivo_json, indent=4)

        print("Nova consulta registrada com sucesso!")
        # Verifica se o procedimento escolhido existe e mostra o valor
        if procedimento in self.tratamentos:
            print(f"O valor total é de R${self.tratamentos[procedimento]:0.2f}")
        else:
            print("Procedimento inválido.")

    # Método para gerenciar histórico e mostrar consultas registradas
    def gerenciar_historico(self):
        with open("exercicio07Procedimentos.json", "r") as arquivo_json:
            dados = json.load(arquivo_json)

        for item in dados:
            print(f"Nome: {item['Nome']}")
            print(f"Horário: {item['Horario']}")
            print(f"Procedimento: {item['Procedimento']}")
            print()

# Instâncias das classes
belezapura = BelezaPura()
clinicaestetica = ClinicaEstetica("Clínica Estética", "Rua 1", 0, 0)
procedimentos = Procedimentos("Procedimentos", "Rua 2", 0, 0)

# Loop principal
while True:
    print("Bem-vindo à Beleza Pura! O que deseja fazer?")
    print("1 - Ir para Clínica Estética")
    print("2 - Ir para Procedimentos")
    print("3 - Sair")
    opcao = int(input("Digite a opção desejada: "))
    if opcao == 1:
        print("Bem-vindo à Clínica Estética! O que deseja fazer?")
        print("1 - Ver tratamentos")
        print("2 - Agendar consulta")
        print("3 - Gerenciar histórico")
        print("4 - Sair")
        opcao = int(input("Digite a opção desejada: "))
        if opcao == 1:
            clinicaestetica.tratamento_cliente()
        elif opcao == 2:
            clinicaestetica.agendar_consulta()
        elif opcao == 3:
            clinicaestetica.gerenciar_historico()
        elif opcao == 4:
            break
    elif opcao == 2:
        print("Bem-vindo aos Procedimentos! O que deseja fazer?")
        print("1 - Ver tratamentos")
        print("2 - Agendar consulta")
        print("3 - Gerenciar histórico")
        print("4 - Sair")
        opcao = int(input("Digite a opção desejada: "))
        if opcao == 1:
            procedimentos.tratamento_cliente()
        elif opcao == 2:
            procedimentos.agendar_consulta()
        elif opcao == 3:
            procedimentos.gerenciar_historico()
        elif opcao == 4:
            break
    elif opcao == 3:
        break
    else:
        print("Opção inválida!")
