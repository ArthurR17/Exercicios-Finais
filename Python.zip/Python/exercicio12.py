import json

print("{0:-^90}".format(""))
print("{0:-^90}".format(" YOGA E PILATES - AURORA EXECUTION "))
print("{0:-^90}".format(""))


class EstudioYogaPilates:
    # Método construtor
    def __init__(self, nomeEstudio, localizacao, aulasAgendadas, clientes):
        self.nomeEstudio = nomeEstudio
        self.localizacao = localizacao
        self.aulasAgendadas = aulasAgendadas
        self.clientes = clientes
    
    # Método para exibir informações de agendamento
    def agendarAula(self):
        with open("exercicio12AulasAgendadas.json", "r") as file:
            dados = json.load(file)
        
        nome_aluno = input("Digite o nome do aluno: ")
        nome_professor = input("Digite o nome do professor: ")
        nivel_aluno = input("Digite o nível do aluno: ")
        dias_semana = input("Digite quais dias da semana o aluno irá fazer a aula: ")
        horario = input("Digite o horário da aula: ")

        # Cria um dicionário com os dados da nova aula
        nova_aula = {
            "Nome do aluno": nome_aluno,
            "Nome do professor": nome_professor,
            "Nivel do aluno": nivel_aluno,
            "Dias da semana": dias_semana,
            "Horario": horario
        }

        # Adiciona os dados no arquivo JSON
        dados.append(nova_aula)

        # Salva os dados no arquivo JSON
        with open("exercicio12AulasAgendadas.json", "w") as arquivo_json:
            json.dump(dados, arquivo_json, indent=4)

        print(f"\nNova aula com o aluno {nome_aluno} agendada com sucesso!")
    
    def cancelarAula(self):
        with open("exercicio12AulasAgendadas.json", "r") as arquivo_json:
            dados = json.load(arquivo_json)

        nome_aluno = input("Digite o nome do aluno para cancelar a aula: ")

        for item in dados:
            if item["Nome do aluno"] == nome_aluno:
                dados.remove(item)
                print(f"\nA aula com o aluno {nome_aluno} foi cancelada com sucesso!")
                break
        else:
            print(f"A aula com o aluno {nome_aluno} não foi encontrada.")

        with open("exercicio12AulasAgendadas.json", "w") as arquivo_json:
            json.dump(dados, arquivo_json, indent=4)
    
    def cancelarAulaPersonalizada(self):
        with open("exercicio12AulasPersonalizadas.json", "r") as arquivo_json:
            dados = json.load(arquivo_json)

        nome_aluno = input("Digite o nome do aluno para cancelar a aula: ")

        for item in dados:
            if item["Nome do aluno"] == nome_aluno:
                dados.remove(item)
                print(f"\nA aula personalizada com o aluno {nome_aluno} foi cancelada com sucesso!")
                break
        else:
            print(f"\nA aula personalizada com o aluno {nome_aluno} não foi encontrada.")

        with open("exercicio12AulasPersonalizadas.json", "w") as arquivo_json:
            json.dump(dados, arquivo_json, indent=4)
    
    def rastrearProgresso(self):
        with open("exercicio12AulasAgendadas.json", "r") as arquivo_json:
            dados = json.load(arquivo_json)

        nome_aluno = input("Digite o nome do aluno para rastrear o progresso: ")

        for item in dados:
            if item["Nome do aluno"] == nome_aluno:
                print(f"\nO aluno {nome_aluno} tem aula com o professor {item['Nome do professor']} nos dias {item['Dias da semana']} às {item['Horario']}.")
                break
        else:
            print(f"O aluno {nome_aluno} não tem aula agendada.")
    
    def rastrearProgressoPersonalizado(self):
        with open("exercicio12AulasPersonalizadas.json", "r") as arquivo_json:
            dados = json.load(arquivo_json)

        nome_aluno = input("Digite o nome do aluno para rastrear o progresso: ")

        for item in dados:
            if item["Nome do aluno"] == nome_aluno:
                print(f"\nO aluno {nome_aluno} com aula personalizada tem aula com o professor {item['Nome do professor']} nos dias {item['Dias da semana']} às {item['Horario']}.")
                break
        else:
            print(f"O aluno {nome_aluno} não tem aula agendada.")
    
    def oferecerAulaPersonalizada(self):
        with open("exercicio12AulasPersonalizadas.json", "r") as arquivo_json:
            dados = json.load(arquivo_json)

        nome_aluno = input("Digite o nome do aluno para oferecer aula personalizada: ")
        nome_professor = input("Digite o nome do professor: ")
        nivel_aluno = input("Digite o nível do aluno: ")
        tipo_aula = input("Digite o tipo de aula personalizada: ")
        dias_semana = input("Digite quais dias da semana o aluno irá fazer a aula: ")
        horario = input("Digite o horário da aula: ")

        nova_aula = {
            "Nome do aluno": nome_aluno,
            "Nome do professor": nome_professor,
            "Nivel do aluno": nivel_aluno,
            "Tipo de aula": tipo_aula,
            "Dias da semana": dias_semana,
            "Horario": horario
        }

        dados.append(nova_aula)

        with open("exercicio12AulasPersonalizadas.json", "w") as arquivo_json:
            json.dump(dados, arquivo_json, indent=4)

        print(f"\nNova aula personalizada com o aluno {nome_aluno} agendada com sucesso!")
    
    def gerenciarEventoEspecial(self):
        with open("exercicio12EventosEspeciais.json", "r") as arquivo_json:
            dados = json.load(arquivo_json)

        nome_organizador = input("Digite o nome do aluno para gerenciar o evento especial: ")
        nome_evento = input("Digite o nome do evento: ")
        local_evento = input("Digite o local do evento: ")
        data_evento = input("Digite a data do evento: ")
        horario_evento = input("Digite o horário do evento: ")

        novo_evento = {
            "Nome do organizador": nome_organizador,
            "Nome do evento": nome_evento,
            "Local do evento": local_evento,
            "Data do evento": data_evento,
            "Horario do evento": horario_evento
        }

        dados.append(novo_evento)

        with open("exercicio12EventosEspeciais.json", "w") as arquivo_json:
            json.dump(dados, arquivo_json, indent=4)

        print(f"\nNovo evento especial com {nome_organizador} agendado com sucesso!")
    
    def removerEventoEspecial(self):
        with open("exercicio12EventosEspeciais.json", "r") as arquivo_json:
            dados = json.load(arquivo_json)

        nome_evento = input("Digite o nome do evento para cancelar o evento especial: ")

        for item in dados:
            if item["Nome do evento"] == nome_evento:
                dados.remove(item)
                print(f"\nEvento chamado {nome_evento} foi cancelada com sucesso!")
                break
        else:
            print(f"\nO evento chamado{nome_evento} não foi encontrada.")

        
        with open("exercicio12EventosEspeciais.json", "w") as arquivo_json:
            json.dump(dados, arquivo_json, indent=4)


estudio = EstudioYogaPilates("Aurora Execution", "Rua Bla bla, 301", "aulasAgendadas.json", "clientes.json")

while True:
    print("Seja bem-vindo(a) ao Estúdio de Yoga e Pilates Aurora Execution!\n")
    print("O que deseja fazer?")
    print("1 - Agendar aula")
    print("2 - Cancelar aula")
    print("3 - Rastrear progresso do aluno")
    print("4 - Oferecer aula personalizada")
    print("5 - Gerenciar evento especial")
    print("6 - Sair")
    opcao = input("Digite a opção desejada: ")

    if opcao == '1':
        estudio.agendarAula()
    elif opcao == '2':
        print("\nDeseja cancelar aula agendada ou aula personalizada?")
        print("1 - Aula agendada")
        print("2 - Aula personalizada")
        opcao = input("Digite a opção desejada: ")
        if opcao == '1':
            estudio.cancelarAula()
        elif opcao == '2':
            estudio.cancelarAulaPersonalizada()
    elif opcao == '3':
        print("\nDeseja rastrear progresso do aluno ou rastrear progresso do aluno com aula personalizada?")
        print("1 - Rastrear progresso do aluno")
        print("2 - Rastrear progresso do aluno com aula personalizada")
        opcao = input("Digite a opção desejada: ")
        if opcao == '1':
            estudio.rastrearProgresso()
        elif opcao == '2':
            estudio.rastrearProgressoPersonalizado()
    elif opcao == '4':
        estudio.oferecerAulaPersonalizada()
    elif opcao == '5':
        print("\nDeseja adicionar evento especial ou remover evento especial?")
        print("1 - Adicionar evento especial")
        print("2 - Remover evento especial")
        opcao = input("Digite a opção desejada: ")
        if opcao == '1':
            estudio.gerenciarEventoEspecial()
        elif opcao == '2':
            estudio.removerEventoEspecial()
    elif opcao == '6':
        print("Obrigado por utilizar nosso software do Estúdio de Yoga e Pilates Aurora Execution. Volte sempre!")
        break
        



        

        