print("-" * 87)
print("-" * 25 + " ESTÚDIO DE FOTOGRAFIA - FINAL FLASH " + "-" * 25)
print("-" * 87)


class FinalFlash:
    def __init__(self, cameras, iluminacao, modelo, fotografo, cenario):
        self.cameras = cameras
        self.iluminacao = iluminacao
        self.modelo = modelo
        self.fotografo = fotografo
        self.cenario = cenario


class Agendamento(FinalFlash):
    def __init__(self, cameras, iluminacao, modelo, fotografo, cenario):
        super().__init__(cameras, iluminacao, modelo, fotografo, cenario)

    # Método para agendar sessão fotográfica
    def agendar_sessao(self, cliente, data, horario):
        print(f"\nSessão agendada para o cliente {cliente} em {data} às {horario}.\n")


class Pacotes(Agendamento):
    def __init__(self, cameras, iluminacao, modelo, fotografo, cenario):
        super().__init__(cameras, iluminacao, modelo, fotografo, cenario)
        self.opcoes_pacotes = {
            "Pacote Básico": {"Quantidade": 5, "Tamanho": "10x15", "Preço": 100.0},
            "Pacote Padrão": {"Quantidade": 10, "Tamanho": "13x18", "Preço": 150.0},
            "Pacote Premium": {"Quantidade": 15, "Tamanho": "15x21", "Preço": 200.0}
        }

    # Método para mostrar opções de pacotes
    def mostrar_opcoes_pacotes(self):
        print("Opções de Pacotes:")
        for pacote, detalhes in self.opcoes_pacotes.items():
            print(f"{pacote} - Quantidade: {detalhes['Quantidade']}, Tamanho: {detalhes['Tamanho']}, Preço: R${detalhes['Preço']:.2f}")
        print()

    def calcular_preco_pacote(self, pacote_escolhido):
        return self.opcoes_pacotes[pacote_escolhido]["Preço"]

    def calcular_preco_total(self):
        preco_total = 0.0
        for item in [self.cameras, self.iluminacao, self.modelo, self.fotografo, self.cenario]:
            preco_total += self.calcular_preco_item(item)
        return preco_total

    def calcular_preco_item(self, item):
        precos = {
            "Canon 5D": 50.0,
            "Canon 6D": 40.0,
            "Nikon D850": 60.0,
            "Softbox": 20.0,
            "LED": 15.0,
            "Flash": 30.0,
            "Profissional": 25.0,
            "Iniciante": 15.0,
            "Avançado": 30.0,
            "Cidade": 25.0,
            "Estúdio Branco": 15.0,
            "Estúdio Preto": 20.0
        }
        return precos.get(item, 0.0)


class EntregaFotos(Pacotes):
    def __init__(self, cameras, iluminacao, modelo, fotografo, cenario):
        super().__init__(cameras, iluminacao, modelo, fotografo, cenario)

    def agendar_entrega(self, cliente, data, horario):
        print(f"\nEntrega agendada para o cliente {cliente} em {data} às {horario}.")

    def mostrar_opcoes_horarios(self):
        print("Opções de Horários para Agendamento e Entrega:")
        horarios_disponiveis = ["10:00", "14:00", "16:00"]
        for horario in horarios_disponiveis:
            print(horario)
        print()


print("Bem-vindo(a) ao Estúdio de Fotografia Final Flash!\n")


# Solicitar informações ao usuário
print("Escolha as opções abaixo para o realizamento da sessão fotográfica:\n")
cameras = input("Câmera:\nCanon 5D - R$40,00\nCanon 6D - R$50,00\nNikon D850 - R$60,00\n\nDigite o nome da câmera:")
iluminacao = input("\nIluminação:\nSoftbox - R$20,00\nLED - R$15,00\nFlash - R$30,00\n\nEscolha um tipo de iluminação: ")
modelo = input("\nEstúdio:\nInciante - R$15,00\nProfissional - R$25,00\nAvançado - R$30,00\n\nEscolha um tipo de modelo de estúdio: ")
fotografo = input("\nDigite o nome do fotógrafo: ")
cenario = input("\nCenário:\nEstúdio Branco - R$15,00\nEstúdio Preto - R$20,00\nCidade - R$25,00\n\nEscolha um tipo de cenário: ")

# Criar instâncias das classes
agendamento = Agendamento(cameras, iluminacao, modelo, fotografo, cenario)
pacotes = Pacotes(cameras, iluminacao, modelo, fotografo, cenario)
entrega_fotos = EntregaFotos(cameras, iluminacao, modelo, fotografo, cenario)

# Solicitar informações adicionais ao usuário
cliente = input("Digite o nome do cliente: ")

# Agendar sessão fotográfica
data_agendamento = input("Digite a data para agendamento (formato: DD-MM): ")
horario_agendamento = input("Escolha o horário para agendamento (08:00 até 17:00):")
agendamento.agendar_sessao(cliente, data_agendamento, horario_agendamento)

# Mostrar opções de pacotes
pacotes.mostrar_opcoes_pacotes()
pacote_escolhido = input("Escolha o pacote desejado: ")

# Agendar entrega de fotos
data_entrega = input("Digite a data para a entrega de fotos (formato: DD-MM): ")
horario_entrega = input("Escolha o horário para a entrega de fotos:")
entrega_fotos.agendar_entrega(cliente, data_entrega, horario_entrega)

# Calcular preços
preco_pacotes = pacotes.calcular_preco_pacote(pacote_escolhido)
preco_total = preco_pacotes + pacotes.calcular_preco_total()
print(f"\nPreço Total: R${preco_total:.2f}")
