import datetime


def cifra_cesar_modificada(texto, esfera, dia_ativacao):
    alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    # Calcular o deslocamento com base na esfera e dia de ativação
    deslocamento = sum([ord(letra.upper()) - ord('A') + 1 for letra in esfera]) + dia_ativacao

    texto_cifrado = ""
    for char in texto:
        if char.isalpha():
            if char.isupper():
                codigo = (ord(char) - ord('A') + deslocamento) % 26 + ord('A')
            else:
                codigo = (ord(char) - ord('a') + deslocamento) % 26 + ord('a')
            texto_cifrado += chr(codigo)
        else:
            texto_cifrado += char
    return texto_cifrado


# Lista de esferas
esferas = {
    "Esfera do Norte": "Gembu",
    "Esfera do Oeste": "Byakko",
    "Esfera do Sul": "Suzaku",
    "Esfera do Leste": "Seiryu",
    "Esfera do Centro": "Songoku"
}

dia_ativacao = datetime.datetime.now().day

# Apresentação das esferas
print("Descubra a senha de cada esfera abaixo:")
for nome_esfera, senha in esferas.items():
    print(f"{nome_esfera}: {senha}")

print("X" + "-" * 15 + "X")
print("Dica: A senha é a quantidade de letras do nome da esfera + o número da esfera")

for nome_esfera, senha in esferas.items():
    texto_cifrado = cifra_cesar_modificada(senha, nome_esfera, dia_ativacao)  # Use a mesma dia_ativacao
    print(f"Texto cifrado de {nome_esfera}: {texto_cifrado}")

# Loop para tentar acertar cada esfera
for nome_esfera, senha_esperada in esferas.items():
    acertou = False
    while not acertou:
        senha = input(f"Digite a senha para {nome_esfera}: ").upper()  # Converter a senha para maiúsculas
        senha_cifrada = cifra_cesar_modificada(senha_esperada, nome_esfera, dia_ativacao).upper()
        if senha == senha_cifrada:
            print(f"Parabéns, você abriu a esfera {nome_esfera}!\n")
            acertou = True
        else:
            print("Senha incorreta. Tente novamente.\n")
