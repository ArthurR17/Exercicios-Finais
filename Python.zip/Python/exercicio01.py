def calcular_total_pedido(itens_pedidos):
    total = 0
    for item, preco in itens_pedidos:
        total += preco
    return total


# Obtenha os itens e preços do usuário
itens_pedido = []
while True:
    item = input("Digite o nome do item (ou 'fim' para encerrar): ")
    if item.lower() == 'fim':
        break
    preco = float(input("Digite o preço do item: "))
    itens_pedido.append((item, preco))

# Calcule o total do pedido e imprima o resultado
total_pedido = calcular_total_pedido(itens_pedido)
print(f"Total do pedido: R${total_pedido:.2f}")
