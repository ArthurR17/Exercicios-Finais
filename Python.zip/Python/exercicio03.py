caixoes = [
    ["Caixão de Madeira", 1000],
    ["Caixão de Metal", 2000],
    ["Caixão de Fibra", 3000],
    ["Caixão de Luxo: Madeira", 5000],
    ["Caixão de Cerejeira", 7500],
    ["Caixão de Marmore", 10000],
]

altura = [
    ["Abaixo de 1.40", 550],
    ["1.40", 700],
    ["1.50", 850],
    ["1.60", 1000],
    ["1.70", 1150],
    ["1.80", 1300],
    ["1.90", 1450],
    ["2.00", 1600],
    ["Acima de 2.00", 1750],
]

flores = [
    ["Rosas", 100],
    ["Margaridas", 200],
    ["Cravos", 300],
    ["Lírios", 400],
    ["Orquídeas", 500],
]


def calcular_custo_funeral():
    print("Bem-Vindo a Funerária Santa Luzia, sua morte nossa alegria!")
    print("Opções de Caixões: \n")
    valor_total = 0
    for item in caixoes:
        print(f"{item[0]} - R${item[1]:0.2f}")
    print("\nOpções de Altura: \n")
    for item in altura:
        print(f"{item[0]}m - R${item[1]:0.2f}")
    print("\nOpções de Flores: \n")
    for item in flores:
        print(f"Buquê de {item[0]} - R${item[1]:0.2f}")
    while True:
        nome_caixao = input("Digite o nome do caixão: ")
        nome_altura = input("Digite a altura do falecido: ")
        nome_flores = input("Digite o nome do buquê de flores: ")
        for item in caixoes:
            if nome_caixao == item[0]:
                valor_total += item[1]
        for item in altura:
            if nome_altura == item[0]:
                valor_total += item[1]
        for item in flores:
            if nome_flores == item[0]:
                valor_total += item[1]
        print(f"O valor total do funeral é de R${valor_total:0.2f}")


calcular_custo_funeral()
