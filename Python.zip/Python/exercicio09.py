print("-" * 99)
print("-" * 25 + " LOJA E OFICINA DE AUTOMÓVEIS - TITAN ATTACK CAR " + "-" * 25)
print("-" * 99)

class Veiculo:
    def __init__(self, marca, modelo, ano, cor):
        self.marca = marca
        self.modelo = modelo
        self.ano = ano
        self.cor = cor

    def exibir_dados(self):
        pass  


class Carro(Veiculo):
    def __init__(self, marca, modelo, ano, cor, num_portas):
        super().__init__(marca, modelo, ano, cor)
        self.num_portas = num_portas

    # Método para exibir dados do carro
    def exibir_dados(self):
        print(f"\nMarca: {self.marca}")
        print(f"Modelo: {self.modelo}")
        print(f"Ano: {self.ano}")
        print(f"Cor: {self.cor}")
        print(f"Número de portas: {self.num_portas}")
        print()


class Moto(Veiculo):
    def __init__(self, marca, modelo, ano, cor, tipo):
        super().__init__(marca, modelo, ano, cor)
        self.tipo = tipo
    
    # Método para exibir dados da moto
    def exibir_dados(self):
        print(f"Marca: {self.marca}")
        print(f"Modelo: {self.modelo}")
        print(f"Ano: {self.ano}")
        print(f"Cor: {self.cor}")
        print(f"Tipo: {self.tipo}")
        print()


class Caminhao(Veiculo):
    def __init__(self, marca, modelo, ano, cor, carga_maxima):
        super().__init__(marca, modelo, ano, cor)
        self.carga_maxima = carga_maxima

    # Método para exibir dados do caminhão
    def exibir_dados(self):
        print(f"Marca: {self.marca}")
        print(f"Modelo: {self.modelo}")
        print(f"Ano: {self.ano}")
        print(f"Cor: {self.cor}")
        print(f"Carga Máxima: {self.carga_maxima}")
        print()


# Listas para armazenar os veículos registrados
carros_registrados = []
motos_registradas = []
caminhoes_registrados = []

while True:
    print("Bem-vindo à Titan Attack Car! O que deseja fazer?")
    print("1 - Registrar veículo")
    print("2 - Ver veículos registrados")
    print("3 - Sair")
    opcao = int(input("Digite a opção desejada: "))

    if opcao == 1:
        print("Escolha o tipo de veículo que deseja registrar:")
        print("1 - Carro")
        print("2 - Moto")
        print("3 - Caminhão")
        opcao = int(input("Digite a opção desejada: "))
        if opcao == 1:
            print("Digite os dados do carro:")
            marca = input("Marca: ")
            modelo = input("Modelo: ")
            ano = input("Ano: ")
            cor = input("Cor: ")
            num_portas = input("Número de portas: ")

            # Cria uma instância da classe Carro
            carro = Carro(marca, modelo, ano, cor, num_portas)

            # Adiciona o carro na lista de carros registrados
            carros_registrados.append(carro)

            print("\nCarro registrado com sucesso!\n")
        elif opcao == 2:
            print("Digite os dados da moto:")
            marca = input("Marca: ")
            modelo = input("Modelo: ")
            ano = input("Ano: ")
            cor = input("Cor: ")
            tipo = input("Tipo: ")

            # Cria uma instância da classe Moto
            moto = Moto(marca, modelo, ano, cor, tipo)

            # Adiciona a moto na lista de motos registradas
            motos_registradas.append(moto)

            print("\nMoto registrada com sucesso!\n")
        elif opcao == 3:
            print("Digite os dados do caminhão:")
            marca = input("Marca: ")
            modelo = input("Modelo: ")
            ano = input("Ano: ")
            cor = input("Cor: ")
            carga_maxima = input("Carga máxima: ")

            # Cria uma instância da classe Caminhao
            caminhao = Caminhao(marca, modelo, ano, cor, carga_maxima)

            # Adiciona o caminhão na lista de caminhões registrados
            caminhoes_registrados.append(caminhao)

            print("\nCaminhão registrado com sucesso!\n")
    elif opcao == 2:
        print("Veículos registrados:")
        print("1 - Carro")
        print("2 - Moto")
        print("3 - Caminhão")
        opcao = int(input("Digite a opção desejada: "))
        # Exibe os dados dos veículos registrados
        if opcao == 1:
            for carro in carros_registrados:
                carro.exibir_dados()
        elif opcao == 2:
            for moto in motos_registradas:
                moto.exibir_dados()
        elif opcao == 3:
            for caminhao in caminhoes_registrados:
                caminhao.exibir_dados()
    elif opcao == 3:
        break
