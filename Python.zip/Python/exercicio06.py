# Classe principal Acayajin
class Acayajin:
    def __init__(self, estoque_produtos):
        self.estoque_produtos = estoque_produtos

# Classes derivadas de Acayajin representando diferentes tipos de açaí
class AcaiBanana(Acayajin):
    def __init__(self, estoque_produtos, quantidade, valor):
        super().__init__(estoque_produtos)
        self.quantidade = quantidade
        self.valor = valor

    def calcular_valor(self):
        valor_total = self.quantidade * self.valor
        self.estoque_produtos -= self.quantidade
        print(f"Vendido {self.quantidade} unidades por R${valor_total:0.2f}")
        return valor_total

class AcaiMorango(Acayajin):
    def __init__(self, estoque_produtos, quantidade, valor):
        super().__init__(estoque_produtos)
        self.quantidade = quantidade
        self.valor = valor

    def calcular_valor(self):
        valor_total = self.quantidade * self.valor
        self.estoque_produtos -= self.quantidade
        print(f"Vendido {self.quantidade} unidades por R${valor_total:0.2f}")
        return valor_total

class AcaiGranola(Acayajin):
    def __init__(self, estoque_produtos, quantidade, valor):
        super().__init__(estoque_produtos)
        self.quantidade = quantidade
        self.valor = valor

    def calcular_valor(self):
        valor_total = self.quantidade * self.valor
        self.estoque_produtos -= self.quantidade
        print(f"Vendido {self.quantidade} unidades por R${valor_total:0.2f}")
        return valor_total

class AcaiPuro(Acayajin):
    def __init__(self, estoque_produtos, quantidade, valor):
        super().__init__(estoque_produtos)
        self.quantidade = quantidade
        self.valor = valor

    def calcular_valor(self):
        valor_total = self.quantidade * self.valor
        self.estoque_produtos -= self.quantidade
        print(f"Vendido {self.quantidade} unidades por R${valor_total:0.2f}")
        return valor_total

# Instâncias das classes representando diferentes tipos de açaí
acai_banana = AcaiBanana(20, 0, 15)
acai_morango = AcaiMorango(15, 0, 25)
acai_granola = AcaiGranola(35, 0, 17)
acai_puro = AcaiPuro(50, 0, 12)

# Loop principal do programa
while True:
    print("Estoque de Açaí: ")
    print("Opções")
    print("1 - Verificar estoque")
    print("2 - Realizar venda")
    print("3 - Sair")

    # Recebe a opção do usuário
    opcao = int(input("Digite a opção desejada: "))

    if opcao == 1:
        # Exibe o estoque atual de cada tipo de açaí
        print(f"Estoque de Açaí de Banana: {acai_banana.estoque_produtos}")
        print(f"Estoque de Açaí de Morango: {acai_morango.estoque_produtos}")
        print(f"Estoque de Açaí de Granola: {acai_granola.estoque_produtos}")
        print(f"Estoque de Açaí Puro: {acai_puro.estoque_produtos}")
    elif opcao == 2:
        # Opções de venda de açaí
        print("Opções de Açaí: ")
        print("1 - Açaí de Banana")
        print("2 - Açaí de Morango")
        print("3 - Açaí de Granola")
        print("4 - Açaí Puro")
        opcao_acai = int(input("Digite a opção desejada: "))

        if opcao_acai == 1:
            # Venda de Açaí de Banana
            acai_banana.quantidade = int(input("Digite a quantidade desejada: "))
            if acai_banana.quantidade > acai_banana.estoque_produtos:
                if acai_banana.estoque_produtos > 0:
                    print(f"Estoque insuficiente! Digite um valor menor ou igual a {acai_banana.estoque_produtos}")
                else:
                    print("Estoque esgotado!")
            else:
                acai_banana.calcular_valor()
        elif opcao_acai == 2:
            # Venda de Açaí de Morango
            acai_morango.quantidade = int(input("Digite a quantidade desejada: "))
            if acai_morango.quantidade > acai_morango.estoque_produtos:
                if acai_morango.estoque_produtos > 0:
                    print(f"Estoque insuficiente! Digite um valor menor ou igual a {acai_morango.estoque_produtos}")
                else:
                    print("Estoque esgotado!")
            else:
                acai_morango.calcular_valor()
        elif opcao_acai == 3:
            # Venda de Açaí de Granola
            acai_granola.quantidade = int(input("Digite a quantidade desejada: "))
            if acai_granola.quantidade > acai_granola.estoque_produtos:
                if acai_granola.estoque_produtos > 0:
                    print(f"Estoque insuficiente! Digite um valor menor ou igual a {acai_granola.estoque_produtos}")
                else:
                    print("Estoque esgotado!")
            else:
                acai_granola.calcular_valor()
        elif opcao_acai == 4:
            # Venda de Açaí Puro
            acai_puro.quantidade = int(input("Digite a quantidade desejada: "))
            if acai_puro.quantidade > acai_puro.estoque_produtos:
                if acai_puro.estoque_produtos > 0:
                    print(f"Estoque insuficiente! Digite um valor menor ou igual a {acai_puro.estoque_produtos}")
                else:
                    print("Estoque esgotado!")
            else:
                acai_puro.calcular_valor()
        else:
            # Mensagem para opção inválida
            print("Opção inválida!")
    elif opcao == 3:
        # Finaliza o programa
        break
    else:
        # Mensagem para opção inválida
        print("Opção inválida!")
